--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4
-- Dumped by pg_dump version 13.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE water_v1;
--
-- Name: water_v1; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE water_v1 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'Russian_Kazakhstan.1251';


ALTER DATABASE water_v1 OWNER TO postgres;

\connect water_v1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Accounts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Accounts" (
    "Id" uuid NOT NULL,
    "Login" text NOT NULL,
    "Bin" text,
    "PasswordHash" text NOT NULL,
    "FullNameRu" text,
    "FullNameKk" text,
    "StreetName" text,
    "BuildingNumber" text,
    "KatoCode" bigint NOT NULL,
    "IsActive" boolean NOT NULL,
    "AuthorId" uuid,
    "CreateDate" timestamp with time zone,
    "LastModifiedDate" timestamp with time zone,
    "IsDel" boolean NOT NULL,
    "Desctiption" text NOT NULL
);


ALTER TABLE public."Accounts" OWNER TO postgres;

--
-- Name: COLUMN "Accounts"."Desctiption"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Accounts"."Desctiption" IS 'Примечания';


--
-- Name: ActionLogs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ActionLogs" (
    "Id" uuid NOT NULL,
    "AccountId" uuid NOT NULL,
    "FormId" uuid NOT NULL,
    "CreateDate" timestamp with time zone NOT NULL,
    "LastModifiedDate" timestamp with time zone NOT NULL,
    "Description" text,
    "Error" text
);


ALTER TABLE public."ActionLogs" OWNER TO postgres;

--
-- Name: ApprovedFormItemColumns; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ApprovedFormItemColumns" (
    "Id" uuid NOT NULL,
    "ApprovedFormItemId" uuid NOT NULL,
    "DataType" integer NOT NULL,
    "ThRu" text NOT NULL,
    "ThKk" text NOT NULL,
    "DisplayOrder" integer NOT NULL
);


ALTER TABLE public."ApprovedFormItemColumns" OWNER TO postgres;

--
-- Name: COLUMN "ApprovedFormItemColumns"."DataType"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItemColumns"."DataType" IS 'Тип хранимых данных: Label(Просто отображение), IntegerType, DecimalType, StringType, BooleanType, DateType, CalcType';


--
-- Name: COLUMN "ApprovedFormItemColumns"."ThRu"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItemColumns"."ThRu" IS 'Заголовок столбца на ру';


--
-- Name: COLUMN "ApprovedFormItemColumns"."ThKk"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItemColumns"."ThKk" IS 'Заголовок столбца на Qaz';


--
-- Name: COLUMN "ApprovedFormItemColumns"."DisplayOrder"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItemColumns"."DisplayOrder" IS 'Порядок отображения';


--
-- Name: ApprovedFormItems; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ApprovedFormItems" (
    "Id" uuid NOT NULL,
    "ApprovedFormId" uuid NOT NULL,
    "ServiceId" integer NOT NULL,
    "Title" text NOT NULL,
    "DisplayOrder" integer NOT NULL,
    "IsDel" boolean NOT NULL
);


ALTER TABLE public."ApprovedFormItems" OWNER TO postgres;

--
-- Name: COLUMN "ApprovedFormItems"."ServiceId"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItems"."ServiceId" IS 'Сервис. 0 - водоснабжение, 1- водоотведение, 2- водопровод';


--
-- Name: COLUMN "ApprovedFormItems"."Title"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItems"."Title" IS 'Заголовок Формы (короткий)';


--
-- Name: COLUMN "ApprovedFormItems"."DisplayOrder"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItems"."DisplayOrder" IS 'Порядок отображения';


--
-- Name: COLUMN "ApprovedFormItems"."IsDel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedFormItems"."IsDel" IS 'Идентификатор удаления';


--
-- Name: ApprovedForms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ApprovedForms" (
    "Id" uuid NOT NULL,
    "Description" text NOT NULL,
    "ApprovalDate" timestamp with time zone NOT NULL,
    "CompletionDate" timestamp with time zone,
    "IsDel" boolean NOT NULL,
    "DeletedById" uuid
);


ALTER TABLE public."ApprovedForms" OWNER TO postgres;

--
-- Name: COLUMN "ApprovedForms"."Description"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedForms"."Description" IS 'Информация о создании группы форм';


--
-- Name: COLUMN "ApprovedForms"."ApprovalDate"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedForms"."ApprovalDate" IS 'Дата утверждения';


--
-- Name: COLUMN "ApprovedForms"."CompletionDate"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedForms"."CompletionDate" IS 'Дата завершения утвержденной формы';


--
-- Name: COLUMN "ApprovedForms"."IsDel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedForms"."IsDel" IS 'Идентификатор удаления';


--
-- Name: COLUMN "ApprovedForms"."DeletedById"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."ApprovedForms"."DeletedById" IS 'Идентификатор пользователя удалившего форму';


--
-- Name: Consumers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Consumers" (
    "Id" uuid NOT NULL,
    "SupplierId" uuid NOT NULL,
    "Ref_KatoId" integer
);


ALTER TABLE public."Consumers" OWNER TO postgres;

--
-- Name: Pipelines; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Pipelines" (
    "Id" uuid NOT NULL,
    "FormId" uuid NOT NULL,
    "TotalPipelineLength" numeric NOT NULL,
    "WornPipelineLength" numeric NOT NULL,
    "TotalSewerNetworkLength" numeric NOT NULL,
    "WornSewerNetworkLength" numeric NOT NULL,
    "NewWaterSupplyNetworkLength" numeric NOT NULL,
    "NewWastewaterNetworkLength" numeric NOT NULL,
    "ReconstructedNetworkLength" numeric NOT NULL,
    "ReconstructedWastewaterNetworkLength" numeric NOT NULL,
    "RepairedWaterSupplyNetworkLength" numeric NOT NULL,
    "RepairedWastewaterNetworkLength" numeric NOT NULL,
    "TotalPopulation" numeric NOT NULL,
    "AuthorId" uuid,
    "CreateDate" timestamp with time zone,
    "LastModifiedDate" timestamp with time zone,
    "IsDel" boolean NOT NULL,
    "Desctiption" text NOT NULL
);


ALTER TABLE public."Pipelines" OWNER TO postgres;

--
-- Name: COLUMN "Pipelines"."TotalPipelineLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."TotalPipelineLength" IS 'Протяженность водопроводных сетей, км (по состоянию на конец отчетного года),общая, км';


--
-- Name: COLUMN "Pipelines"."WornPipelineLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."WornPipelineLength" IS 'в том числе изношенных, км';


--
-- Name: COLUMN "Pipelines"."TotalSewerNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."TotalSewerNetworkLength" IS 'Протяженность канализационных сетей, км (по состоянию на конец отчетного года),общая, км';


--
-- Name: COLUMN "Pipelines"."WornSewerNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."WornSewerNetworkLength" IS 'в том числе изношенных, км';


--
-- Name: COLUMN "Pipelines"."NewWaterSupplyNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."NewWaterSupplyNetworkLength" IS 'Общая протяженность построенных (новых) сетей в отчетном году, км, водоснабжения, км';


--
-- Name: COLUMN "Pipelines"."NewWastewaterNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."NewWastewaterNetworkLength" IS 'водоотведения, км';


--
-- Name: COLUMN "Pipelines"."ReconstructedNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."ReconstructedNetworkLength" IS 'Общая протяженность реконструированных (замененных) сетей в отчетном году, км, водоснабжения, км';


--
-- Name: COLUMN "Pipelines"."ReconstructedWastewaterNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."ReconstructedWastewaterNetworkLength" IS 'водоотведения, км';


--
-- Name: COLUMN "Pipelines"."RepairedWaterSupplyNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."RepairedWaterSupplyNetworkLength" IS 'Общая протяженность отремонтированных (текущий/капитальный ремонт) сетей в отчетном году, км, водоснабжения, км';


--
-- Name: COLUMN "Pipelines"."RepairedWastewaterNetworkLength"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."RepairedWastewaterNetworkLength" IS 'водоотведения, км';


--
-- Name: COLUMN "Pipelines"."TotalPopulation"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."TotalPopulation" IS 'численность населения (вся)';


--
-- Name: COLUMN "Pipelines"."Desctiption"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Pipelines"."Desctiption" IS 'Примечания';


--
-- Name: Ref_Buildings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ref_Buildings" (
    "Id" integer NOT NULL,
    "RefStreetId" integer NOT NULL,
    "Building" text NOT NULL,
    "NameRu" text NOT NULL,
    "NameKk" text,
    "IsDel" boolean NOT NULL,
    "Description" text
);


ALTER TABLE public."Ref_Buildings" OWNER TO postgres;

--
-- Name: Ref_Buildings_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Ref_Buildings" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."Ref_Buildings_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Ref_Katos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ref_Katos" (
    "Id" integer NOT NULL,
    "ParentId" integer NOT NULL,
    "Code" bigint NOT NULL,
    "Latitude" numeric,
    "Longitude" numeric,
    "UserId" uuid,
    "IsReportable" boolean NOT NULL,
    "KatoLevel" integer,
    "NameRu" text NOT NULL,
    "NameKk" text,
    "IsDel" boolean NOT NULL,
    "Description" text
);


ALTER TABLE public."Ref_Katos" OWNER TO postgres;

--
-- Name: COLUMN "Ref_Katos"."KatoLevel"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Ref_Katos"."KatoLevel" IS 'Категории населенных пунктов. 1-городские(города республиканского, областного и районного значения,поселки), 2-сельские(все остальные)';


--
-- Name: Ref_Katos_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Ref_Katos" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."Ref_Katos_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Ref_Statuses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ref_Statuses" (
    "Id" integer NOT NULL,
    "NameRu" text NOT NULL,
    "NameKk" text,
    "IsDel" boolean NOT NULL,
    "Description" text
);


ALTER TABLE public."Ref_Statuses" OWNER TO postgres;

--
-- Name: Ref_Statuses_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Ref_Statuses" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."Ref_Statuses_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Ref_Streets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Ref_Streets" (
    "Id" integer NOT NULL,
    "RefKatoId" integer NOT NULL,
    "NameRu" text NOT NULL,
    "NameKk" text,
    "IsDel" boolean NOT NULL,
    "Description" text
);


ALTER TABLE public."Ref_Streets" OWNER TO postgres;

--
-- Name: Ref_Streets_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."Ref_Streets" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."Ref_Streets_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Report_Forms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Report_Forms" (
    "Id" uuid NOT NULL,
    "RefKatoId" integer NOT NULL,
    "SupplierId" integer,
    "SupplierId1" uuid,
    "ReportYearId" integer NOT NULL,
    "ReportMonthId" integer NOT NULL,
    "RefStatusId" integer NOT NULL,
    "HasStreets" boolean NOT NULL,
    "AuthorId" uuid,
    "CreateDate" timestamp with time zone,
    "LastModifiedDate" timestamp with time zone,
    "IsDel" boolean NOT NULL,
    "Desctiption" text NOT NULL
);


ALTER TABLE public."Report_Forms" OWNER TO postgres;

--
-- Name: COLUMN "Report_Forms"."HasStreets"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Report_Forms"."HasStreets" IS 'Наличие улиц в селе';


--
-- Name: COLUMN "Report_Forms"."Desctiption"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Report_Forms"."Desctiption" IS 'Примечания';


--
-- Name: SettingsValues; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SettingsValues" (
    "Id" integer NOT NULL,
    "Key" text NOT NULL,
    "Value" text NOT NULL
);


ALTER TABLE public."SettingsValues" OWNER TO postgres;

--
-- Name: SettingsValues_Id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public."SettingsValues" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public."SettingsValues_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: Suppliers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Suppliers" (
    "Id" uuid NOT NULL,
    "Bin" text NOT NULL,
    "FullName" text NOT NULL
);


ALTER TABLE public."Suppliers" OWNER TO postgres;

--
-- Name: Tariff_Level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Tariff_Level" (
    "Id" uuid NOT NULL,
    "FormId" uuid NOT NULL,
    "TariffAverage" numeric NOT NULL,
    "TariffIndividual" numeric NOT NULL,
    "TariffLegal" numeric NOT NULL,
    "TariffBudget" numeric NOT NULL,
    "AuthorId" uuid,
    "CreateDate" timestamp with time zone,
    "LastModifiedDate" timestamp with time zone,
    "IsDel" boolean NOT NULL,
    "Desctiption" text NOT NULL
);


ALTER TABLE public."Tariff_Level" OWNER TO postgres;

--
-- Name: COLUMN "Tariff_Level"."TariffAverage"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Tariff_Level"."TariffAverage" IS 'усредненный, тенге/м3';


--
-- Name: COLUMN "Tariff_Level"."TariffIndividual"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Tariff_Level"."TariffIndividual" IS 'физическим лицам/населению, тенге/м3';


--
-- Name: COLUMN "Tariff_Level"."TariffLegal"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Tariff_Level"."TariffLegal" IS 'юридическим лицам, тенге/м3';


--
-- Name: COLUMN "Tariff_Level"."TariffBudget"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Tariff_Level"."TariffBudget" IS 'бюджетным организациям, тенге/м3';


--
-- Name: COLUMN "Tariff_Level"."Desctiption"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN public."Tariff_Level"."Desctiption" IS 'Примечания';


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public."__EFMigrationsHistory" OWNER TO postgres;

--
-- Data for Name: Accounts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Accounts" ("Id", "Login", "Bin", "PasswordHash", "FullNameRu", "FullNameKk", "StreetName", "BuildingNumber", "KatoCode", "IsActive", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Desctiption") FROM stdin;
\.
COPY public."Accounts" ("Id", "Login", "Bin", "PasswordHash", "FullNameRu", "FullNameKk", "StreetName", "BuildingNumber", "KatoCode", "IsActive", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Desctiption") FROM '$$PATH$$/3119.dat';

--
-- Data for Name: ActionLogs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ActionLogs" ("Id", "AccountId", "FormId", "CreateDate", "LastModifiedDate", "Description", "Error") FROM stdin;
\.
COPY public."ActionLogs" ("Id", "AccountId", "FormId", "CreateDate", "LastModifiedDate", "Description", "Error") FROM '$$PATH$$/3128.dat';

--
-- Data for Name: ApprovedFormItemColumns; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ApprovedFormItemColumns" ("Id", "ApprovedFormItemId", "DataType", "ThRu", "ThKk", "DisplayOrder") FROM stdin;
\.
COPY public."ApprovedFormItemColumns" ("Id", "ApprovedFormItemId", "DataType", "ThRu", "ThKk", "DisplayOrder") FROM '$$PATH$$/3134.dat';

--
-- Data for Name: ApprovedFormItems; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ApprovedFormItems" ("Id", "ApprovedFormId", "ServiceId", "Title", "DisplayOrder", "IsDel") FROM stdin;
\.
COPY public."ApprovedFormItems" ("Id", "ApprovedFormId", "ServiceId", "Title", "DisplayOrder", "IsDel") FROM '$$PATH$$/3129.dat';

--
-- Data for Name: ApprovedForms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ApprovedForms" ("Id", "Description", "ApprovalDate", "CompletionDate", "IsDel", "DeletedById") FROM stdin;
\.
COPY public."ApprovedForms" ("Id", "Description", "ApprovalDate", "CompletionDate", "IsDel", "DeletedById") FROM '$$PATH$$/3120.dat';

--
-- Data for Name: Consumers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Consumers" ("Id", "SupplierId", "Ref_KatoId") FROM stdin;
\.
COPY public."Consumers" ("Id", "SupplierId", "Ref_KatoId") FROM '$$PATH$$/3132.dat';

--
-- Data for Name: Pipelines; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Pipelines" ("Id", "FormId", "TotalPipelineLength", "WornPipelineLength", "TotalSewerNetworkLength", "WornSewerNetworkLength", "NewWaterSupplyNetworkLength", "NewWastewaterNetworkLength", "ReconstructedNetworkLength", "ReconstructedWastewaterNetworkLength", "RepairedWaterSupplyNetworkLength", "RepairedWastewaterNetworkLength", "TotalPopulation", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Desctiption") FROM stdin;
\.
COPY public."Pipelines" ("Id", "FormId", "TotalPipelineLength", "WornPipelineLength", "TotalSewerNetworkLength", "WornSewerNetworkLength", "NewWaterSupplyNetworkLength", "NewWastewaterNetworkLength", "ReconstructedNetworkLength", "ReconstructedWastewaterNetworkLength", "RepairedWaterSupplyNetworkLength", "RepairedWastewaterNetworkLength", "TotalPopulation", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Desctiption") FROM '$$PATH$$/3137.dat';

--
-- Data for Name: Ref_Buildings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ref_Buildings" ("Id", "RefStreetId", "Building", "NameRu", "NameKk", "IsDel", "Description") FROM stdin;
\.
COPY public."Ref_Buildings" ("Id", "RefStreetId", "Building", "NameRu", "NameKk", "IsDel", "Description") FROM '$$PATH$$/3136.dat';

--
-- Data for Name: Ref_Katos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ref_Katos" ("Id", "ParentId", "Code", "Latitude", "Longitude", "UserId", "IsReportable", "KatoLevel", "NameRu", "NameKk", "IsDel", "Description") FROM stdin;
\.
COPY public."Ref_Katos" ("Id", "ParentId", "Code", "Latitude", "Longitude", "UserId", "IsReportable", "KatoLevel", "NameRu", "NameKk", "IsDel", "Description") FROM '$$PATH$$/3122.dat';

--
-- Data for Name: Ref_Statuses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ref_Statuses" ("Id", "NameRu", "NameKk", "IsDel", "Description") FROM stdin;
\.
COPY public."Ref_Statuses" ("Id", "NameRu", "NameKk", "IsDel", "Description") FROM '$$PATH$$/3124.dat';

--
-- Data for Name: Ref_Streets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Ref_Streets" ("Id", "RefKatoId", "NameRu", "NameKk", "IsDel", "Description") FROM stdin;
\.
COPY public."Ref_Streets" ("Id", "RefKatoId", "NameRu", "NameKk", "IsDel", "Description") FROM '$$PATH$$/3131.dat';

--
-- Data for Name: Report_Forms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Report_Forms" ("Id", "RefKatoId", "SupplierId", "SupplierId1", "ReportYearId", "ReportMonthId", "RefStatusId", "HasStreets", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Desctiption") FROM stdin;
\.
COPY public."Report_Forms" ("Id", "RefKatoId", "SupplierId", "SupplierId1", "ReportYearId", "ReportMonthId", "RefStatusId", "HasStreets", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Desctiption") FROM '$$PATH$$/3133.dat';

--
-- Data for Name: SettingsValues; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SettingsValues" ("Id", "Key", "Value") FROM stdin;
\.
COPY public."SettingsValues" ("Id", "Key", "Value") FROM '$$PATH$$/3126.dat';

--
-- Data for Name: Suppliers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Suppliers" ("Id", "Bin", "FullName") FROM stdin;
\.
COPY public."Suppliers" ("Id", "Bin", "FullName") FROM '$$PATH$$/3127.dat';

--
-- Data for Name: Tariff_Level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Tariff_Level" ("Id", "FormId", "TariffAverage", "TariffIndividual", "TariffLegal", "TariffBudget", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Desctiption") FROM stdin;
\.
COPY public."Tariff_Level" ("Id", "FormId", "TariffAverage", "TariffIndividual", "TariffLegal", "TariffBudget", "AuthorId", "CreateDate", "LastModifiedDate", "IsDel", "Desctiption") FROM '$$PATH$$/3138.dat';

--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
\.
COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM '$$PATH$$/3118.dat';

--
-- Name: Ref_Buildings_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ref_Buildings_Id_seq"', 1, false);


--
-- Name: Ref_Katos_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ref_Katos_Id_seq"', 1, false);


--
-- Name: Ref_Statuses_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ref_Statuses_Id_seq"', 1, false);


--
-- Name: Ref_Streets_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Ref_Streets_Id_seq"', 1, false);


--
-- Name: SettingsValues_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SettingsValues_Id_seq"', 2, true);


--
-- Name: Accounts PK_Accounts; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Accounts"
    ADD CONSTRAINT "PK_Accounts" PRIMARY KEY ("Id");


--
-- Name: ActionLogs PK_ActionLogs; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActionLogs"
    ADD CONSTRAINT "PK_ActionLogs" PRIMARY KEY ("Id");


--
-- Name: ApprovedFormItemColumns PK_ApprovedFormItemColumns; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApprovedFormItemColumns"
    ADD CONSTRAINT "PK_ApprovedFormItemColumns" PRIMARY KEY ("Id");


--
-- Name: ApprovedFormItems PK_ApprovedFormItems; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApprovedFormItems"
    ADD CONSTRAINT "PK_ApprovedFormItems" PRIMARY KEY ("Id");


--
-- Name: ApprovedForms PK_ApprovedForms; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApprovedForms"
    ADD CONSTRAINT "PK_ApprovedForms" PRIMARY KEY ("Id");


--
-- Name: Consumers PK_Consumers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Consumers"
    ADD CONSTRAINT "PK_Consumers" PRIMARY KEY ("Id");


--
-- Name: Pipelines PK_Pipelines; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pipelines"
    ADD CONSTRAINT "PK_Pipelines" PRIMARY KEY ("Id");


--
-- Name: Ref_Buildings PK_Ref_Buildings; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Buildings"
    ADD CONSTRAINT "PK_Ref_Buildings" PRIMARY KEY ("Id");


--
-- Name: Ref_Katos PK_Ref_Katos; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Katos"
    ADD CONSTRAINT "PK_Ref_Katos" PRIMARY KEY ("Id");


--
-- Name: Ref_Statuses PK_Ref_Statuses; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Statuses"
    ADD CONSTRAINT "PK_Ref_Statuses" PRIMARY KEY ("Id");


--
-- Name: Ref_Streets PK_Ref_Streets; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Streets"
    ADD CONSTRAINT "PK_Ref_Streets" PRIMARY KEY ("Id");


--
-- Name: Report_Forms PK_Report_Forms; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report_Forms"
    ADD CONSTRAINT "PK_Report_Forms" PRIMARY KEY ("Id");


--
-- Name: SettingsValues PK_SettingsValues; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SettingsValues"
    ADD CONSTRAINT "PK_SettingsValues" PRIMARY KEY ("Id");


--
-- Name: Suppliers PK_Suppliers; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Suppliers"
    ADD CONSTRAINT "PK_Suppliers" PRIMARY KEY ("Id");


--
-- Name: Tariff_Level PK_Tariff_Level; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tariff_Level"
    ADD CONSTRAINT "PK_Tariff_Level" PRIMARY KEY ("Id");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: IX_ActionLogs_AccountId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_ActionLogs_AccountId" ON public."ActionLogs" USING btree ("AccountId");


--
-- Name: IX_ApprovedFormItemColumns_ApprovedFormItemId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_ApprovedFormItemColumns_ApprovedFormItemId" ON public."ApprovedFormItemColumns" USING btree ("ApprovedFormItemId");


--
-- Name: IX_ApprovedFormItems_ApprovedFormId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_ApprovedFormItems_ApprovedFormId" ON public."ApprovedFormItems" USING btree ("ApprovedFormId");


--
-- Name: IX_Consumers_Ref_KatoId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Consumers_Ref_KatoId" ON public."Consumers" USING btree ("Ref_KatoId");


--
-- Name: IX_Consumers_SupplierId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Consumers_SupplierId" ON public."Consumers" USING btree ("SupplierId");


--
-- Name: IX_Pipelines_FormId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Pipelines_FormId" ON public."Pipelines" USING btree ("FormId");


--
-- Name: IX_Ref_Buildings_RefStreetId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Ref_Buildings_RefStreetId" ON public."Ref_Buildings" USING btree ("RefStreetId");


--
-- Name: IX_Ref_Streets_RefKatoId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Ref_Streets_RefKatoId" ON public."Ref_Streets" USING btree ("RefKatoId");


--
-- Name: IX_Report_Forms_RefKatoId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Report_Forms_RefKatoId" ON public."Report_Forms" USING btree ("RefKatoId");


--
-- Name: IX_Report_Forms_RefStatusId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Report_Forms_RefStatusId" ON public."Report_Forms" USING btree ("RefStatusId");


--
-- Name: IX_Report_Forms_SupplierId1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Report_Forms_SupplierId1" ON public."Report_Forms" USING btree ("SupplierId1");


--
-- Name: IX_Tariff_Level_FormId; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IX_Tariff_Level_FormId" ON public."Tariff_Level" USING btree ("FormId");


--
-- Name: ActionLogs FK_ActionLogs_Accounts_AccountId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ActionLogs"
    ADD CONSTRAINT "FK_ActionLogs_Accounts_AccountId" FOREIGN KEY ("AccountId") REFERENCES public."Accounts"("Id") ON DELETE CASCADE;


--
-- Name: ApprovedFormItemColumns FK_ApprovedFormItemColumns_ApprovedFormItems_ApprovedFormItemId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApprovedFormItemColumns"
    ADD CONSTRAINT "FK_ApprovedFormItemColumns_ApprovedFormItems_ApprovedFormItemId" FOREIGN KEY ("ApprovedFormItemId") REFERENCES public."ApprovedFormItems"("Id") ON DELETE CASCADE;


--
-- Name: ApprovedFormItems FK_ApprovedFormItems_ApprovedForms_ApprovedFormId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ApprovedFormItems"
    ADD CONSTRAINT "FK_ApprovedFormItems_ApprovedForms_ApprovedFormId" FOREIGN KEY ("ApprovedFormId") REFERENCES public."ApprovedForms"("Id") ON DELETE CASCADE;


--
-- Name: Consumers FK_Consumers_Ref_Katos_Ref_KatoId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Consumers"
    ADD CONSTRAINT "FK_Consumers_Ref_Katos_Ref_KatoId" FOREIGN KEY ("Ref_KatoId") REFERENCES public."Ref_Katos"("Id");


--
-- Name: Consumers FK_Consumers_Suppliers_SupplierId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Consumers"
    ADD CONSTRAINT "FK_Consumers_Suppliers_SupplierId" FOREIGN KEY ("SupplierId") REFERENCES public."Suppliers"("Id") ON DELETE CASCADE;


--
-- Name: Pipelines FK_Pipelines_Report_Forms_FormId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Pipelines"
    ADD CONSTRAINT "FK_Pipelines_Report_Forms_FormId" FOREIGN KEY ("FormId") REFERENCES public."Report_Forms"("Id") ON DELETE CASCADE;


--
-- Name: Ref_Buildings FK_Ref_Buildings_Ref_Streets_RefStreetId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Buildings"
    ADD CONSTRAINT "FK_Ref_Buildings_Ref_Streets_RefStreetId" FOREIGN KEY ("RefStreetId") REFERENCES public."Ref_Streets"("Id") ON DELETE CASCADE;


--
-- Name: Ref_Streets FK_Ref_Streets_Ref_Katos_RefKatoId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Ref_Streets"
    ADD CONSTRAINT "FK_Ref_Streets_Ref_Katos_RefKatoId" FOREIGN KEY ("RefKatoId") REFERENCES public."Ref_Katos"("Id") ON DELETE CASCADE;


--
-- Name: Report_Forms FK_Report_Forms_Ref_Katos_RefKatoId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report_Forms"
    ADD CONSTRAINT "FK_Report_Forms_Ref_Katos_RefKatoId" FOREIGN KEY ("RefKatoId") REFERENCES public."Ref_Katos"("Id") ON DELETE CASCADE;


--
-- Name: Report_Forms FK_Report_Forms_Ref_Statuses_RefStatusId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report_Forms"
    ADD CONSTRAINT "FK_Report_Forms_Ref_Statuses_RefStatusId" FOREIGN KEY ("RefStatusId") REFERENCES public."Ref_Statuses"("Id") ON DELETE CASCADE;


--
-- Name: Report_Forms FK_Report_Forms_Suppliers_SupplierId1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Report_Forms"
    ADD CONSTRAINT "FK_Report_Forms_Suppliers_SupplierId1" FOREIGN KEY ("SupplierId1") REFERENCES public."Suppliers"("Id");


--
-- Name: Tariff_Level FK_Tariff_Level_Report_Forms_FormId; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Tariff_Level"
    ADD CONSTRAINT "FK_Tariff_Level_Report_Forms_FormId" FOREIGN KEY ("FormId") REFERENCES public."Report_Forms"("Id") ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

